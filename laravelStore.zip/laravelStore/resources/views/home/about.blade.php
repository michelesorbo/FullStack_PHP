@extends('layouts.app')
@section('subtitle', 'Benvenuto in About')
@section('content')
<h1>Ciao a tutti</h1>
{{ $saluto }}
@endsection
