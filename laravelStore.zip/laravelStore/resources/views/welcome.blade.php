@extends('layouts.app')
@section('title', 'Home Page di Store Laravel')
@section('subtitle','Ciao Michele')
@section('content')
<div class="text-center">
    Benvenuto nello nuovo store di Laravel
</div>
@endsection
