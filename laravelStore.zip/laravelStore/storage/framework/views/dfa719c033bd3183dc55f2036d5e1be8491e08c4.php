<?php $__env->startSection('title', 'Home Page di Store Laravel'); ?>
<?php $__env->startSection('subtitle','Ciao Michele'); ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
    Benvenuto nello nuovo store di Laravel
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/FullStack_PHP/laravelStore/resources/views/welcome.blade.php ENDPATH**/ ?>