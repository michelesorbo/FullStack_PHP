<?php $__env->startSection('subtitle', 'Benvenuto in About'); ?>
<?php $__env->startSection('content'); ?>
<h1>Ciao a tutti</h1>
<?php echo e($saluto); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/FullStack_PHP/laravelStore/resources/views/home/about.blade.php ENDPATH**/ ?>